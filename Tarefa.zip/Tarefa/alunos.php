<?php
    include "./layout/cabecalho.php";
?>

<h1>Alunos</h1>

<?php

    include "./layout/rodape.php";
?>