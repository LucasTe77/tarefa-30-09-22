<?php
    include "./layout/cabecalho.php";
?>

<h1>Professores</h1>

<?php

    include "./layout/rodape.php";
?>