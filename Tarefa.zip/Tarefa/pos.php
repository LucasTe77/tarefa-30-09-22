<?php
    include "./layout/cabecalho.php";
?>

<h1>Pós Graduação</h1>

<?php

    include "./layout/rodape.php";
?>