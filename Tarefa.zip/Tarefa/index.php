<?php
    include "./layout/cabecalho.php";
?>
<h1>Bem vindo à Brasil Escola</h1>
<?php

    include "./layout/rodape.php";
?>