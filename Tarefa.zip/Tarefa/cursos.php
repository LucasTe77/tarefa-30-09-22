<?php
    include "./layout/cabecalho.php";
?>

<h1>Cursos</h1>

<?php

    include "./layout/rodape.php";
?>