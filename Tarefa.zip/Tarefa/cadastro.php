<?php
    include "./layout/cabecalho.php";
?>

<h1>Cadastro</h1>

<?php

    include "./layout/rodape.php";
?>